<?php include "template/header.php";




?>



<div class="container">
    <h1>Hello, world!</h1>
    <p>rizal faizisfd Lorem ipsum dolor sit amet, consectetur adipisicing elit. Numquam accusamus odit quam dicta
        et,
        dolorem, consectetur id voluptatibus sed nihil a at unde, veniam non amet magnam aliquam qui mollitia?</p>
    <?php include "home.php"; ?>
</div>

<?php include "template/footer.php";

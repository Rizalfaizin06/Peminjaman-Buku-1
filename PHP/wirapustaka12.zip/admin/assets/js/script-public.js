$(document).ready(function () {

	setInterval(function () {
		jQuery.ajax({
			type: "GET",
			url: "admin/assets/ajax/warning-public.php",
			data: "",
			success: function (data) {
				$("#tablePeringatan").html(data);
			}
		});
	}, 60000);

	setInterval(function () {
		jQuery.ajax({
			type: "GET",
			url: "admin/assets/ajax/pengunjung-public.php",
			data: "",
			success: function (data) {
				$("#listPengunjung").html(data);
			}
		});
	}, 1000);

	setInterval(function () {
		jQuery.ajax({
			type: "GET",
			url: "admin/assets/ajax/buku-public.php",
			data: "",
			success: function (data) {
				$("#tableBuku").html(data);
			}
		});
	}, 1000);

	setInterval(function () {
		jQuery.ajax({
			type: "GET",
			url: "admin/assets/ajax/absensi-public.php",
			data: "",
			success: function (data) {
				$("#tableAbsen").html(data);
			}
		});
	}, 1000);




});
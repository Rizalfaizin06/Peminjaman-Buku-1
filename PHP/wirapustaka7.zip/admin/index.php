<?php include "template/header.php";
?>



<div class="container" style="min-height: 405px;">
    <?php include "../index.php"; ?>
</div>

<?php include "template/footer.php";

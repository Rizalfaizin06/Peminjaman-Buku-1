<?php include "template/header.php";
?>



<div class="container" style="min-height: 65vh;">
    <?php include "../index.php"; ?>
</div>

<?php include "template/footer.php";

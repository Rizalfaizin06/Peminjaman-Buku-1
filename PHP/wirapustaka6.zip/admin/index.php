<?php include "template/header.php";




?>



<div class="container" style="min-height: 405px;">
    <?php include "../index.php"; ?>
</div>
<script>
    document.getElementById("loginAdmin").style.visibility = "hidden";
</script>

<?php include "template/footer.php";

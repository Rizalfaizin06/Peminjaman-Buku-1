<?php include "template/header.php";

if (!isset($_SESSION["login"])) {
    header("location: login.php");
    exit;
}



?>



<div class="container" style="min-height: 405px;">
    <div class="text-center mb-3">
        <h1>WIRAPUSTAKA</h1>
        <h3>SMKN 1 WIROSARI</h3>
    </div>
    <?php include "home.php"; ?>
</div>

<?php include "template/footer.php";

<?php
session_start();
echo $_SESSION['filter'];
echo $_SESSION['tanggal'];
